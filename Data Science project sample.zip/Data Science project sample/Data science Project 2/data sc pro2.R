mydata<- read.csv("D:/heart_failure_clinical_records_dataset.csv",header = TRUE, sep =",")
mydata
sum(is.na(mydata))
mydata$sex<-factor(mydata$sex,
                      levels=c(0,1),
                      labels=c("male","female"))
mydata

cor(mydata$age,mydata$DEATH_EVENT)
cor(mydata$anaemia,mydata$DEATH_EVENT)
cor(mydata$creatinine,mydata$DEATH_EVENT)
cor(mydata$diabetes,mydata$DEATH_EVENT)
cor(mydata$ejection_fraction,mydata$DEATH_EVENT)
cor(mydata$high_blood_pressure,mydata$DEATH_EVENT)
cor(mydata$platelets,mydata$DEATH_EVENT)
cor(mydata$serum_creatinine,mydata$DEATH_EVENT)
cor(mydata$serum_sodium,mydata$DEATH_EVENT)
cor(mydata$sex,mydata$DEATH_EVENT)
cor(mydata$smoking,mydata$DEATH_EVENT)
cor(mydata$time,mydata$DEATH_EVENT)
cor(mydata)

install.packages("corrplot")
library(corrplot)
library(RColorBrewer)
mydata <-cor(mtcars)
corrplot(mydata, type="upper", order="hclust",
         col=brewer.pal(n=8, name="RdYlBu"))




data_split <- sample(1:nrow(mydata), 0.8 * nrow(mydata))


train <- mydata[data_split,]
head(train)
dim(train)

test <- mydata[-data_split,]
head(test)
dim(test)

target_category <- mydata[data_split,12]
test_category <- mydata[-data_split,12]
target_category
test_category

install.packages("class")
library(class)
test_pred <- knn(train,test,cl=target_category,k=5)
test_pred
df_pred=data.frame(test_category,test_pred)
df_pred
table <- table(test_category,test_pred)
table




install.packages("caret")
predicted <- c(0, 1, 1, 0, 0, 1, 0, 0)
actual <- c(1, 0, 1, 0, 1, 1, 0, 0)
xtab <- table(predicted, actual)
library(caret)
cm <- caret::confusionMatrix(xtab)
cm

library(Metrics)
predicted <- c(1, 1, 1, 0, 1, 0, 1, 1)
actual <- c(1, 0, 0, 1, 1, 1, 1,0, 1)
Metrics::recall(predicted, actual)

predicted <- c(1, 1, 1, 0, 1, 1, 1, 1)
actual <- c(1, 0, 0, 1, 1, 1, 1,0, 0)
Metrics::precision(predicted, actual)






