mydata<- read.csv("D:/dataset.csv",header = TRUE, sep =",")
mydata
BloodGroup <-c("O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB","B-","O","A","B","A-","AB")
mydata_BloodGroup <- cbind(mydata,BloodGroup)
mydata_BloodGroup
install.packages("tibble")
library(tibble)
new_row <-c(0,89,2,1,"99.69","C","Third","man","TRUE",1)
mydata<-rbind(mydata,new_row)
mydata
str(mydata)
colSums(is.na(mydata))
mydata$Gender<-factor(mydata$Gender,
                        levels=c(1,2,3),
                        labels=c("male","female","child"))
mydata

mean(mydata$fare)
median(mydata$fare)
mode(mydata$fare)

mydata
s<-mydata$fare  
sd(s)

mydata$score = (as.matrix(mydata[c(4,3)]))
mydata$score
is.na(mydata)
which(is.na(mydata$Gender))

remove<- na.omit(mydata)
mydata

sum(is.na(mydata))
summary(mydata)
hist(mydata$age)
hist(mydata$fare)




